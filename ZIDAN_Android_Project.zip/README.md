# ZIDAN — Android Game Project

Game petualangan offline untuk Android dengan:
- Level dan XP
- Koin, energi, misi, hadiah
- Lokasi petualangan yang terbuka seiring level
- Toko dan inventaris
- Penyimpanan progres lokal
- Antarmuka responsif dan tema gelap modern

## Cara menjalankan
1. Buka folder `zidan_android_project` melalui Android Studio.
2. Gunakan JDK 17 atau yang direkomendasikan Android Studio.
3. Biarkan Android Studio mengunduh Android Gradle Plugin dan Android SDK platform 35 bila diminta.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug umumnya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan build
APK belum dibangun di lingkungan pembuatan ini karena Android SDK/Gradle tidak tersedia dan akses jaringan untuk mengunduh dependensi tidak aktif. Source project disiapkan agar bisa dibuka dan dibangun di Android Studio. Game utama juga dapat dimainkan langsung di browser lewat `index.html`, tanpa internet.
