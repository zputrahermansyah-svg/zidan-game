plugins { id("com.android.application") }

android {
    namespace = "com.zidan.game"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.zidan.game"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
